from django.apps import AppConfig


class PetdocsConfig(AppConfig):
    name = 'petdocs'
