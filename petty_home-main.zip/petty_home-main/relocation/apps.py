from django.apps import AppConfig


class RelocationConfig(AppConfig):
    name = 'relocation'
