# petty_home
Проект настроен для деплоя на heroku.

Необходимо добавить postgres в heroku resources.

Прилинковать репозиторий в настройки деплоя heroku.

Запустить деплой.

Страница на heroku: https://pettyhome.herokuapp.com/pets/
